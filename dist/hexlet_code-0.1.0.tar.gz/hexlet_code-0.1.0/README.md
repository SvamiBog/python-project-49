### Hexlet tests and linter status:
[![Actions Status](https://github.com/SvamiBog/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/SvamiBog/python-project-49/actions)

<a href="https://codeclimate.com/github/SvamiBog/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/03ce9072ecd338bfed8c/maintainability" /></a>

Игра: «Проверка на чётность»:
<a href="https://asciinema.org/a/oz6AIWAvfPXDszLNA3HVuB92N" target="_blank"><img src="https://asciinema.org/a/oz6AIWAvfPXDszLNA3HVuB92N.svg" /></a>

Игра: «Калькулятор»:
<a href="https://asciinema.org/a/XCRWLNGH9mymfk21n7LYifxeq" target="_blank"><img src="https://asciinema.org/a/XCRWLNGH9mymfk21n7LYifxeq.svg" /></a>

Игра «НОД»:
<a href="https://asciinema.org/a/ZdY7MRLTU4udpWw14Bl7AIqNO" target="_blank"><img src="https://asciinema.org/a/ZdY7MRLTU4udpWw14Bl7AIqNO.svg" /></a>

Игра «Арифметическая прогрессия»:
<a href="https://asciinema.org/a/82juQvca3zOROr79Ej2uT6sRq" target="_blank"><img src="https://asciinema.org/a/82juQvca3zOROr79Ej2uT6sRq.svg" /></a>

Игра «Простое ли число?»:
<a href="https://asciinema.org/a/BzHFvRkrDWra5xH2NpHcXzDy3" target="_blank"><img src="https://asciinema.org/a/BzHFvRkrDWra5xH2NpHcXzDy3.svg" /></a>
